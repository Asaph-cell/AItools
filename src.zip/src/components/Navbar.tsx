import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Compass } from "lucide-react";

export default function Navbar() {
  return (
    <nav className="sticky top-0 z-50 bg-card/80 backdrop-blur-sm border-b border-surface-border">
      <div className="container max-w-6xl mx-auto flex items-center justify-between h-14 px-4">
        <Link to="/" className="flex items-center gap-2 font-bold text-card-foreground">
          <Compass className="h-5 w-5 text-primary" />
          AI Tool Atlas
        </Link>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="sm" asChild>
            <Link to="/directory">Directory</Link>
          </Button>
          <Button variant="ghost" size="sm" asChild>
            <Link to="/best">Best Of</Link>
          </Button>
          <Button variant="ghost" size="sm" asChild>
            <Link to="/trending">Trending</Link>
          </Button>
          <Button variant="ghost" size="sm" asChild>
            <Link to="/new">New</Link>
          </Button>
          <Button variant="ghost" size="sm" asChild>
            <Link to="/compare">Compare</Link>
          </Button>
          <Button size="sm" asChild>
            <Link to="/matchmaker">Start Quiz</Link>
          </Button>
        </div>
      </div>
    </nav>
  );
}
