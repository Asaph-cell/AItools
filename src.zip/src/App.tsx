import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Home from "./pages/Home";
import Matchmaker from "./pages/Matchmaker";
import Directory from "./pages/Directory";
import Compare from "./pages/Compare";
import ToolDetail from "./pages/ToolDetail";
import BestOf from "./pages/BestOf";
import Trending from "./pages/Trending";
import NewTools from "./pages/NewTools";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/matchmaker" element={<Matchmaker />} />
          <Route path="/directory" element={<Directory />} />
          <Route path="/compare" element={<Compare />} />
          <Route path="/tools/:slug" element={<ToolDetail />} />
          <Route path="/best" element={<BestOf />} />
          <Route path="/best/:category" element={<BestOf />} />
          <Route path="/trending" element={<Trending />} />
          <Route path="/new" element={<NewTools />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
